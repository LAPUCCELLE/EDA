
package Dashboardventanas;

import SistemaGestionTramite.*;
import javax.swing.JDialog;
import javax.swing.JOptionPane;


public class OpcionesInteresado extends javax.swing.JPanel {
    
    private GestionSistema s1;
 
    public OpcionesInteresado() {
        initComponents();
    }
    
    
    public OpcionesInteresado(GestionSistema s1) {
        initComponents();
        this.s1 = s1;
        llenarInteresados();
    }
    
    public void actualizarListaInteresados() {
        listaInteresados.removeAllItems(); 
        llenarInteresados(); 
    }
    
    private void llenarInteresados(){
        listaInteresados.removeAllItems();
        int longitud = s1.getListaInteresados().longitud();
        for (int i = 1; i <= longitud; i++) {
            Interesado interesado = s1.getListaInteresados().iesimo(i);
            if (interesado != null) {
                listaInteresados.addItem(interesado);
            }
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        listaInteresados = new javax.swing.JComboBox<>();
        cambiarDatos = new javax.swing.JButton();
        eliminarInteresado = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        listaInteresados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listaInteresadosActionPerformed(evt);
            }
        });

        cambiarDatos.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        cambiarDatos.setForeground(new java.awt.Color(255, 153, 0));
        cambiarDatos.setText("Cambiar datos");
        cambiarDatos.setBorder(null);
        cambiarDatos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cambiarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cambiarDatosActionPerformed(evt);
            }
        });

        eliminarInteresado.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        eliminarInteresado.setForeground(new java.awt.Color(255, 153, 0));
        eliminarInteresado.setText("Eliminar interesado");
        eliminarInteresado.setBorder(null);
        eliminarInteresado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        eliminarInteresado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarInteresadoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(listaInteresados, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cambiarDatos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                        .addComponent(eliminarInteresado)
                        .addGap(33, 33, 33))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addComponent(listaInteresados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cambiarDatos)
                    .addComponent(eliminarInteresado))
                .addGap(34, 34, 34))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void listaInteresadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listaInteresadosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_listaInteresadosActionPerformed

    private void cambiarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cambiarDatosActionPerformed
        Interesado InteresadoEncontrado = (Interesado)listaInteresados.getSelectedItem();
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                JDialog dialog = new JDialog();
                dialog.setModal(true);
                dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

                cambiarDatos panelContraseña = new cambiarDatos(s1,InteresadoEncontrado,OpcionesInteresado.this );
                dialog.add(panelContraseña);
                dialog.pack();
                dialog.setLocationRelativeTo(null);
                dialog.setVisible(true);
            }
        });
    }//GEN-LAST:event_cambiarDatosActionPerformed

    private void eliminarInteresadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarInteresadoActionPerformed
        
        Object selectedItem = listaInteresados.getSelectedItem();
        if (selectedItem != null && selectedItem instanceof Interesado) {
            Interesado interesado = (Interesado) selectedItem;
            
            s1.eliminarInteresado(interesado);
            JOptionPane.showMessageDialog(null, "Interesado eliminado correctamente");
            listaInteresados.removeAllItems();
            llenarInteresados();
        }else{
            JOptionPane.showMessageDialog(null, "Ya no existen interesados.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        
        /*Interesado InteresadoEncontrado = (Interesado)listaInteresados.getSelectedItem();
        s1.eliminarInteresado(InteresadoEncontrado);
        JOptionPane.showMessageDialog(this, "Interesado eliminado", "Eliminacion de Interesado", JOptionPane.INFORMATION_MESSAGE);
        llenarInteresados();*/
    }//GEN-LAST:event_eliminarInteresadoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cambiarDatos;
    private javax.swing.JButton eliminarInteresado;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<Interesado> listaInteresados;
    // End of variables declaration//GEN-END:variables
}
