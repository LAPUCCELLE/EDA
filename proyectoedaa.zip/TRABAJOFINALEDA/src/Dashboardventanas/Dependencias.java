
package Dashboardventanas;
import SistemaGestionTramite.GestionSistema;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class Dependencias extends javax.swing.JPanel {
    
    private GestionSistema s1;

    public Dependencias() {
        initComponents();
    }
    
    public Dependencias(GestionSistema s1) {
        initComponents();
        this.s1 = s1; 
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        background = new javax.swing.JPanel();
        imagen = new javax.swing.JLabel();
        CrearDependencia = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        Crear = new javax.swing.JButton();
        dependenciatxt = new javax.swing.JTextField();
        Gestionar = new javax.swing.JButton();
        ModificarBtn = new javax.swing.JButton();

        background.setBackground(new java.awt.Color(255, 255, 255));

        imagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Dependencia.png"))); // NOI18N

        CrearDependencia.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        CrearDependencia.setText("Crear dependencia");

        Nombre.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Nombre.setText("Nombre");

        Crear.setBackground(new java.awt.Color(255, 153, 0));
        Crear.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        Crear.setForeground(new java.awt.Color(255, 255, 255));
        Crear.setText("Crear");
        Crear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrearActionPerformed(evt);
            }
        });

        dependenciatxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dependenciatxtActionPerformed(evt);
            }
        });

        Gestionar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        Gestionar.setForeground(new java.awt.Color(255, 153, 0));
        Gestionar.setText("Eliminar");
        Gestionar.setBorder(null);
        Gestionar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Gestionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GestionarActionPerformed(evt);
            }
        });

        ModificarBtn.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        ModificarBtn.setForeground(new java.awt.Color(255, 153, 0));
        ModificarBtn.setText("Modificar");
        ModificarBtn.setBorder(null);
        ModificarBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ModificarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout backgroundLayout = new javax.swing.GroupLayout(background);
        background.setLayout(backgroundLayout);
        backgroundLayout.setHorizontalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, backgroundLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(backgroundLayout.createSequentialGroup()
                        .addComponent(CrearDependencia, javax.swing.GroupLayout.DEFAULT_SIZE, 319, Short.MAX_VALUE)
                        .addGap(30, 30, 30))
                    .addGroup(backgroundLayout.createSequentialGroup()
                        .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dependenciatxt, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Crear, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(backgroundLayout.createSequentialGroup()
                                .addComponent(Gestionar, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(64, 64, 64)
                                .addComponent(ModificarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        backgroundLayout.setVerticalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(CrearDependencia, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dependenciatxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(Crear, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Gestionar)
                    .addComponent(ModificarBtn))
                .addGap(53, 53, 53))
            .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 390, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void CrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrearActionPerformed
        String nombre = dependenciatxt.getText();
        if(nombre.isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe llenar los espacios en blanco", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
        s1.agregarDependencia(nombre);
        JOptionPane.showMessageDialog(null, nombre + " agregada correctamente.");
        this.dependenciatxt.setText(null);
        }
    }//GEN-LAST:event_CrearActionPerformed

    private void dependenciatxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dependenciatxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dependenciatxtActionPerformed

    private void GestionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GestionarActionPerformed
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                JDialog dialog = new JDialog();
                dialog.setModal(true);
                dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

                EliminarDependencia eliminar = new EliminarDependencia(s1);
                dialog.add(eliminar);
                dialog.pack();
                dialog.setLocationRelativeTo(null);
                dialog.setVisible(true);
            }
        });
    }//GEN-LAST:event_GestionarActionPerformed

    private void ModificarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarBtnActionPerformed
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                JDialog dialog = new JDialog();
                dialog.setModal(true);
                dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

                ModificarDependencia modificar = new ModificarDependencia(s1);
                dialog.add(modificar);
                dialog.pack();
                dialog.setLocationRelativeTo(null);
                dialog.setVisible(true);
            }
        });
    }//GEN-LAST:event_ModificarBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Crear;
    private javax.swing.JLabel CrearDependencia;
    private javax.swing.JButton Gestionar;
    private javax.swing.JButton ModificarBtn;
    private javax.swing.JLabel Nombre;
    private javax.swing.JPanel background;
    private javax.swing.JTextField dependenciatxt;
    private javax.swing.JLabel imagen;
    // End of variables declaration//GEN-END:variables

}
