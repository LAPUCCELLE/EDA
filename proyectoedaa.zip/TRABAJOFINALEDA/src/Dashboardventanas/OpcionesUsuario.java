/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Dashboardventanas;

import SistemaGestionTramite.*;
import javax.swing.JDialog;
import javax.swing.JOptionPane;


public class OpcionesUsuario extends javax.swing.JPanel {

    private GestionSistema s1;
    
    
    public OpcionesUsuario(GestionSistema s1) {
        initComponents();
        this.s1=s1;
        llenarUsuarios();
    }
    
    private void llenarUsuarios(){
        listaUsuarios.removeAllItems();
        int longitud = s1.getListaUsuarios().longitud();
        for (int i = 1; i <= longitud; i++) {
            Administrador usuario = s1.getListaUsuarios().iesimo(i);
            if (usuario != null) {
                listaUsuarios.addItem(usuario.getNombreDeUsuario());
            }
        }
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cambiarContraseña = new javax.swing.JButton();
        eliminarUsuario = new javax.swing.JButton();
        listaUsuarios = new javax.swing.JComboBox<>();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        cambiarContraseña.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        cambiarContraseña.setForeground(new java.awt.Color(255, 153, 0));
        cambiarContraseña.setText("Cambiar contraseña");
        cambiarContraseña.setBorder(null);
        cambiarContraseña.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cambiarContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cambiarContraseñaActionPerformed(evt);
            }
        });

        eliminarUsuario.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        eliminarUsuario.setForeground(new java.awt.Color(255, 153, 0));
        eliminarUsuario.setText("Eliminar usuario");
        eliminarUsuario.setBorder(null);
        eliminarUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        eliminarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarUsuarioActionPerformed(evt);
            }
        });

        listaUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listaUsuariosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(listaUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cambiarContraseña)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                        .addComponent(eliminarUsuario)
                        .addGap(21, 21, 21))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(listaUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cambiarContraseña)
                    .addComponent(eliminarUsuario))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void cambiarContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cambiarContraseñaActionPerformed
        String usuario = listaUsuarios.getSelectedItem().toString();
        Administrador AdministradorEncontrado = s1.buscarAdministrador(usuario);
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JDialog dialog = new JDialog();
                dialog.setModal(true);
                dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

                CambiarContrasena cambiar = new CambiarContrasena(s1, AdministradorEncontrado);
                dialog.add(cambiar);
                dialog.pack();
                dialog.setLocationRelativeTo(null);
                dialog.setVisible(true);
            }
        });
    }//GEN-LAST:event_cambiarContraseñaActionPerformed

    private void eliminarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarUsuarioActionPerformed
        String usuario = listaUsuarios.getSelectedItem().toString();
        Administrador AdministradorEncontrado = s1.buscarAdministrador(usuario);
        s1.eliminarAdministrador(AdministradorEncontrado);
        llenarUsuarios();
        JOptionPane.showMessageDialog(this, "Usuario eliminado", "Eliminacion de Usuario", JOptionPane.INFORMATION_MESSAGE);

        // Verificar si la lista de usuarios está vacía y cerrar toda la aplicación si es así
        if (s1.getListaUsuarios().longitud() == 0) {
            System.exit(0);
        }
    }//GEN-LAST:event_eliminarUsuarioActionPerformed

    private void listaUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listaUsuariosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_listaUsuariosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cambiarContraseña;
    private javax.swing.JButton eliminarUsuario;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> listaUsuarios;
    // End of variables declaration//GEN-END:variables
}
