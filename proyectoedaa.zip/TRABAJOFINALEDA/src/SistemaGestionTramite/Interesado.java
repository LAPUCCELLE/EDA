/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaGestionTramite;

/**
 *
 * @author User
 */
public class Interesado {
    private String nombre;
    private int DNI;
    private String tipoInteresado;
    private String telefono;
    private String email;

    public Interesado(String nombre, int DNI, String tipoInteresado, String telefono, String email) {
        this.nombre = nombre;
        this.DNI = DNI;
        this.tipoInteresado = tipoInteresado;
        this.telefono = telefono;
        this.email = email;
    }

    public String getTipoInteresado() {
        return tipoInteresado;
    }

    public void setTipoInteresado(String tipoInteresado) {
        this.tipoInteresado = tipoInteresado;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    @Override
    public String toString() {
        return nombre + " - DNI: " + DNI;
    }
}
