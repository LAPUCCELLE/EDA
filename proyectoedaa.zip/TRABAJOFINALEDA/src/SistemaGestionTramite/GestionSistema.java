
package SistemaGestionTramite;

import TDA.*;
import java.util.UUID;


public class GestionSistema {
    private Lista<Administrador> listaUsuarios;
    private Lista<Interesado> listaInteresados;
    private Lista<Dependencia> listaDependencias;
    

    public GestionSistema() {
        this.listaUsuarios= new Lista<>();
        this.listaInteresados = new Lista<>();
        this.listaDependencias = new Lista<>();
    }
    
    public void agregarAdministrador(String nombreDeUsuario, String contraseña) {
        Administrador nuevoAdministrador = new Administrador(nombreDeUsuario, contraseña);
        listaUsuarios.agregar(nuevoAdministrador);
    }
    
    public boolean autenticarAdministrador(String nombreDeUsuario, String contraseña) {
        Administrador administrador = buscarAdministrador(nombreDeUsuario);
        return administrador != null && administrador.validarAcceso(nombreDeUsuario, contraseña);
    }
    
    public void cambiarContraseñaAdministrador(String nombreDeUsuario, String contraseñaActual, String nuevaContraseña) {
        Administrador administrador = buscarAdministrador(nombreDeUsuario);
        if (administrador != null && administrador.validarAcceso(nombreDeUsuario, contraseñaActual)) {
            administrador.cambiarContraseña(nuevaContraseña);
        }
    }
    
    public void mostrarAdministradores() {
        int longitud = listaUsuarios.longitud();
        for (int i = 1; i <= longitud; i++) {
            Administrador administrador = listaUsuarios.iesimo(i);
            if (administrador != null) {
                System.out.print("Administrador: " + administrador.getNombreDeUsuario() + "\t");
            }
        }
        System.out.println();
    }
    
    public void eliminarAdministrador(Administrador admin) {
        listaUsuarios.eliminar(admin);
    }
    
    public void eliminarDependencia(String nombreDependencia) {
        Dependencia dependencia = buscarDependencia(nombreDependencia);
        listaDependencias.eliminar(dependencia);

    }
    
    public void eliminarInteresado(Interesado interesado) {
        listaInteresados.eliminar(interesado);
    }

    
    public void modificarInteresado(Interesado interesado, String nuevoNombre, int nuevoDNI, String nuevoTipoInteresado, String nuevoTelefono, String nuevoEmail) {
            interesado.setNombre(nuevoNombre);
            interesado.setDNI(nuevoDNI);
            interesado.setTipoInteresado(nuevoTipoInteresado);
            interesado.setTelefono(nuevoTelefono);
            interesado.setEmail(nuevoEmail);
    }
    
    public void modificarDependencia(String nombreDependencia, String nuevoNombre) {
        Dependencia dependencia = buscarDependencia(nombreDependencia);
        dependencia.setNombre(nuevoNombre);
    }
    
    public Administrador buscarAdministrador(String nombreDeUsuario) {
        for (int i = 1; i <= listaUsuarios.longitud(); i++) {
            Administrador administrador = listaUsuarios.iesimo(i);
            if (administrador != null && administrador.getNombreDeUsuario().equals(nombreDeUsuario)) {
                return administrador;
            }
        }
        return null;
    }
    
    public void agregarInteresado(String nombre, int DNI, String tipoInteresado, String telefono, String email) {
        Interesado nuevoInteresado = new Interesado(nombre, DNI, tipoInteresado, telefono, email);
        listaInteresados.agregar(nuevoInteresado);
    }
    
    public void mostrarInteresados() {
        for (int i = 1; i <= listaInteresados.longitud(); i++) {
            Interesado interesado = listaInteresados.iesimo(i);
            if (interesado != null) {
                System.out.print(interesado.toString() + "\t");
            }
        }
        System.out.println();
    }
    
    public void agregarDependencia(String nombreDependencia) {
        Dependencia nuevaDependencia = new Dependencia(nombreDependencia);
        listaDependencias.agregar(nuevaDependencia);
    }
    
    public void mostrarDependencias() {
        for (int i = 1; i <= listaDependencias.longitud(); i++) {
            Dependencia dependencia = listaDependencias.iesimo(i);
            if (dependencia != null) {
                System.out.print(dependencia.toString() + "\t");
            }
        }
        System.out.println();
    }
    
    public void agregarExpediente(int prioridad, Interesado interesado, String asunto, String documentoReferencia, String nombreDependencia) {
        Dependencia dependencia = buscarDependencia(nombreDependencia);
        String idExpediente = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        while (existeIdExpediente(idExpediente)) {
            idExpediente = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        }
        Expediente nuevoExpediente = new Expediente(idExpediente, prioridad, interesado, asunto, documentoReferencia, dependencia);
        dependencia.agregarExpediente(nuevoExpediente);
    }
    
    private boolean existeIdExpediente(String idExpediente) {
        for (int i = 1; i <= listaDependencias.longitud(); i++) {
            Dependencia dependencia = listaDependencias.iesimo(i);
            if (dependencia != null && dependencia.buscarExpediente(idExpediente) != null) {
                return true;
            }
        }
        return false;
    }
    
    public void moverExpediente(String idExpediente, String nombreDependenciaDestino) {
        Expediente expediente = buscarExpediente(idExpediente);
        if (expediente == null) {
            return;
        }

        // Buscar la dependencia destino
        Dependencia dependenciaDestino = buscarDependencia(nombreDependenciaDestino);
        if (dependenciaDestino == null) {
            return;
        }

        // Obtener la dependencia actual y eliminar el expediente de ella
        Dependencia dependenciaActual = expediente.getDependencia();
        if (dependenciaActual != null) {
            dependenciaActual.eliminarExpediente(expediente);
        }

        // Mover el expediente a la nueva dependencia
        expediente.setDependencia(dependenciaDestino);
        expediente.agregarDependenciaHistorial(nombreDependenciaDestino);
        dependenciaDestino.agregarExpediente(expediente);
    }
    

    
    public void finalizarExpediente(String idExpediente, String docResultante) {
        Expediente expediente = buscarExpediente(idExpediente);
        expediente.setDocumentoResultado(docResultante);
        expediente.finalizar();

    }    
    
    public Lista<String> HistorialExpediente(String idExpediente) {
        Expediente expediente = buscarExpediente(idExpediente);
        if (expediente != null) {
            return expediente.getHistorialExpediente();
        } else {
            return new Lista<>();
        }
    }
    
    public void mostrarHistorialExpediente(String idExpediente) {
        Expediente expediente = buscarExpediente(idExpediente);
        if (expediente != null) {
            expediente.mostrarHistorialDependencias();
        } 
    }
    
    public void mostrarExpedientesPorDependencia(String nombreDependencia) {
        Dependencia dependencia = buscarDependencia(nombreDependencia);
        if (dependencia == null) {
            System.out.println("Dependencia no encontrada.");
            return;
        }

        Lista<Expediente> listaExpedientes = dependencia.obtenerTodosLosExpedientes();
        int longitud = listaExpedientes.longitud();
        for (int i = 1; i <= longitud; i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            if (expediente != null) {
                System.out.println(expediente.obtenerDescripcionCompleta());
            }
        }
    }
    
    public Lista<Expediente> obtenerExpedientesPorDependencia(String nombreDependencia) {
        Dependencia dependencia = buscarDependencia(nombreDependencia);
        if (dependencia == null) {
            System.out.println("Dependencia no encontrada.");
            return null;
        }

        return dependencia.obtenerTodosLosExpedientes();
    }
    
    public Lista<Expediente> ExpedientesPorPrioridad(String nombreDependencia) {
        Dependencia dependencia = buscarDependencia(nombreDependencia);
        if (dependencia == null) {
            System.out.println("Dependencia no encontrada.");
            return null;
        }

        return dependencia.obtenerExpedientesPorPrioridad();
    }
    
    public Lista<Expediente> ExpedientesPorFecha(String nombreDependencia) {
        Dependencia dependencia = buscarDependencia(nombreDependencia);
        if (dependencia == null) {
            return null;
        }

        return dependencia.obtenerExpedientesPorAntiguedad();
    }   

    public Expediente buscarExpediente(String idExpediente) {
        for (int i = 1; i <= listaDependencias.longitud(); i++) {
            Dependencia dependencia = listaDependencias.iesimo(i);
            if (dependencia != null) {
                Expediente expediente = dependencia.buscarExpediente(idExpediente);
                if (expediente != null) {
                    return expediente;
                }
            }
        }
        return null;
    }
    
    public Interesado buscarInteresadoPorNombre(String nombre) {
        for (int i = 1; i <= listaInteresados.longitud(); i++) {
            Interesado interesado = listaInteresados.iesimo(i);
            if (interesado != null && interesado.getNombre().equalsIgnoreCase(nombre)) {
                return interesado;
            }
        }
        return null;
    }

    
    public Interesado buscarInteresadporDNI(int dni) {
        for (int i = 1; i <= listaInteresados.longitud(); i++) {
            Interesado interesado = listaInteresados.iesimo(i);
            if (interesado != null && interesado.getDNI() == dni) {
                return interesado;
            }
        }
        return null;
    }
    
   private Dependencia buscarDependencia(String nombreDependencia) {
        for (int i = 1; i <= listaDependencias.longitud(); i++) {
            Dependencia dependencia = listaDependencias.iesimo(i);
            if (dependencia != null && dependencia.getNombre().equals(nombreDependencia)) {
                return dependencia;
            }
        }
        return null;
    }
    
    public void mostrarEstadoExpediente(String idExpediente) {
        Expediente expediente = buscarExpediente(idExpediente);
        if (expediente != null) {
            System.out.println(expediente.obtenerDescripcionCompleta());
        }
    }
    
    public Lista<Expediente> obtenerExpedientesPorInteresado(Interesado interesado) {
        Lista<Expediente> expedientesPorInteresado = new Lista<>();

        for (int i = 1; i <= listaDependencias.longitud(); i++) {
            Dependencia dependencia = listaDependencias.iesimo(i);
            if (dependencia != null) {
                Lista<Expediente> expedientes = dependencia.obtenerTodosLosExpedientes();
                for (int j = 1; j <= expedientes.longitud(); j++) {
                    Expediente expediente = expedientes.iesimo(j);
                    if (expediente != null && expediente.getInteresado().equals(interesado)) {
                        expedientesPorInteresado.agregar(expediente);
                    }
                }
            }
        }

        return expedientesPorInteresado;
    }
    

    public Lista<Administrador> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(Lista<Administrador> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    public Lista<Interesado> getListaInteresados() {
        return listaInteresados;
    }

    public void setListaInteresados(Lista<Interesado> listaInteresados) {
        this.listaInteresados = listaInteresados;
    }

    public Lista<Dependencia> getListaDependencias() {
        return listaDependencias;
    }

    public void setListaDependencias(Lista<Dependencia> listaDependencias) {
        this.listaDependencias = listaDependencias;
    }
    
    
    
}
