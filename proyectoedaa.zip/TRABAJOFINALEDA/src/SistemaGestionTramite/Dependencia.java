/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaGestionTramite;
import TDA.*;

/**
 *
 * @author User
 */
public class Dependencia {
    private String nombre;
    private Lista<Expediente> listaExpedientes;

    public Dependencia(String nombre) {
        this.nombre = nombre;
        this.listaExpedientes = new Lista<>();
    }

    
    public void agregarExpediente(Expediente expediente){
        listaExpedientes.agregar(expediente);
    }
    
    public Expediente buscarExpediente(String idExpediente) {
        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            if (expediente.getIdExpediente().equals(idExpediente)) {
                return expediente;
            }
        }
        return null;
    }
    
    public Expediente moverExpediente() {
        if (!listaExpedientes.esVacia()) {
            return listaExpedientes.iesimo(1); 
        }
        return null;
    }
    
    public void eliminarExpediente(Expediente expediente) {
        listaExpedientes.eliminar(expediente);
    }
    
    public Lista<Expediente> obtenerExpedientesPorPrioridad() {
        Lista<Expediente> listaExpedientesOrdenados = new Lista<>();

        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            if (!expediente.estaAtendido()) {
                listaExpedientesOrdenados.agregar(expediente);
            }
        }

        listaExpedientesOrdenados = ordenarPorPrioridad(listaExpedientesOrdenados);

        return listaExpedientesOrdenados;
    }
    
    
    private Lista<Expediente> ordenarPorPrioridad(Lista<Expediente> lista) {
        // Aquí se muestra una simple ordenación por burbuja 
        for (int i = 1; i < lista.longitud(); i++) {
            for (int j = 1; j < lista.longitud() - i + 1; j++) {
                if (lista.iesimo(j).getPrioridad() > lista.iesimo(j + 1).getPrioridad()) {
                    Expediente temp = lista.iesimo(j);
                    lista.eliminar(j);
                    lista.insertar(temp, j + 1);
                }
            }
        }
        return lista;
    }
   
    public Lista<Expediente> obtenerExpedientesPorAntiguedad() {
        Lista<Expediente> listaExpedientesOrdenados = new Lista<>();

        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            if (!expediente.estaAtendido()) {
                listaExpedientesOrdenados.agregar(expediente);
            }
        }

        return listaExpedientesOrdenados; 
    }
    
    public Lista<Expediente> obtenerTodosLosExpedientes() {
        Lista<Expediente> listaExpedientesCopia = new Lista<>();

        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            listaExpedientesCopia.agregar(expediente);
        }

        return listaExpedientesCopia;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Lista<Expediente> getListaExpedientes() {
        return listaExpedientes;
    }

    public void setListaExpedientes(Lista<Expediente> listaExpedientes) {
        this.listaExpedientes = listaExpedientes;
    }


    @Override
    public String toString() {
        return this.nombre ;
    }
}

