
package Dashboardventanas;

import SistemaGestionTramite.*;



public class HistorialDependencia extends javax.swing.JPanel {

    private GestionSistema s1;
    
    public HistorialDependencia() {
        initComponents();
       
    }
    
    public HistorialDependencia(GestionSistema s1) {
        initComponents();
        this.s1=s1;
           
    }  
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        interesadoList = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListaDependencia = new javax.swing.JTable();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        interesadoList.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        interesadoList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                interesadoListActionPerformed(evt);
            }
        });
        jPanel1.add(interesadoList, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 282, -1));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setText("Selecciona el ID del trámite");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        ListaDependencia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Dependencias"
            }
        ));
        jScrollPane1.setViewportView(ListaDependencia);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 447, 141));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 290, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void interesadoListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_interesadoListActionPerformed
       
    }//GEN-LAST:event_interesadoListActionPerformed

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable ListaDependencia;
    private javax.swing.JComboBox<Interesado> interesadoList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
