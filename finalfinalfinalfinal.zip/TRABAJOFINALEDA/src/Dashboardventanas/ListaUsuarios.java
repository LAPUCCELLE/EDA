
package Dashboardventanas;

import SistemaGestionTramite.*;
import TDA.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Rodrigo
 */
public class ListaUsuarios extends javax.swing.JPanel {

    private GestionSistema s1;
    private DefaultTableModel modeloTabla;
    
    public ListaUsuarios() {
        initComponents();
    }
    
    public ListaUsuarios(GestionSistema s1) {
        initComponents();
        this.s1=s1;
        modeloTabla = new DefaultTableModel();
        this.TableUsuarios.setModel(modeloTabla);
        modeloTabla.addColumn("Nombre de Usuario");
        modeloTabla.addColumn("Contraseña");
        ActualizarTabla();
    }
   
     private void ActualizarTabla(){
        modeloTabla.setRowCount(0);
        Lista listaUsuarios = this.s1.getListaUsuarios();
        for (int i = 1; i <= listaUsuarios.longitud(); i++) {
            Administrador usuario = (Administrador)listaUsuarios.iesimo(i);
            String[] fila = new String[2];
            fila[0] = usuario.getNombreDeUsuario();
            fila[1] = usuario.getContraseña();
            modeloTabla.addRow(fila);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        background = new javax.swing.JPanel();
        ListaUsuarios = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableUsuarios = new javax.swing.JTable();

        background.setBackground(new java.awt.Color(255, 255, 255));

        ListaUsuarios.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        ListaUsuarios.setForeground(new java.awt.Color(255, 153, 0));
        ListaUsuarios.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ListaUsuarios.setText("Lista Usuarios");

        TableUsuarios.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        TableUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Usuario", "Contraseña"
            }
        ));
        jScrollPane1.setViewportView(TableUsuarios);

        javax.swing.GroupLayout backgroundLayout = new javax.swing.GroupLayout(background);
        background.setLayout(backgroundLayout);
        backgroundLayout.setHorizontalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(backgroundLayout.createSequentialGroup()
                        .addGap(114, 114, 114)
                        .addComponent(ListaUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(backgroundLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 495, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        backgroundLayout.setVerticalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(ListaUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ListaUsuarios;
    private javax.swing.JTable TableUsuarios;
    private javax.swing.JPanel background;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
