
package Dashboardventanas;
import SistemaGestionTramite.*;
import TDA.*;
import java.time.format.DateTimeFormatter;
import javax.swing.table.DefaultTableModel;


public class Principal extends javax.swing.JPanel {
 
    private GestionSistema s1;
    private DefaultTableModel modeloTabla;
    private DefaultTableModel modeloTabla2;

    public Principal(GestionSistema s1) {
        this.s1 = s1;
        initComponents();
        modeloTabla = new DefaultTableModel();
        modeloTabla2 = new DefaultTableModel();
        configurarModelosDeTabla();
        llenarDependencias();
    }

    private void configurarModelosDeTabla() {
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Prioridad");
        modeloTabla.addColumn("Asunto");

        modeloTabla2.addColumn("ID");
        modeloTabla2.addColumn("FechaEmision");
        modeloTabla2.addColumn("Asunto");

        this.tablaprioridad.setModel(modeloTabla);
        this.tablafecha.setModel(modeloTabla2);
    }

    private void llenarDependencias() {
        int longitud = s1.getListaDependencias().longitud();
        for (int i = 1; i <= longitud; i++) {
            Dependencia dependencia = s1.getListaDependencias().iesimo(i);
            if (dependencia != null) {
                dependenciatxt.addItem(dependencia.getNombre());
            }
        }
        if (dependenciatxt.getItemCount() > 0) {
            String primeraDependencia = dependenciatxt.getItemAt(0).toString();
            mostrarTablas(primeraDependencia);
        }
    }

    private void mostrarTablas(String dependencia) {
        limpiarTablas();
        mostrarTablaPrioridad(dependencia);
        mostrarTablaFecha(dependencia);
    }

    private void mostrarTablaPrioridad(String dependencia) {
        Lista<Expediente> listaExpedientes = this.s1.ExpedientesPorPrioridad(dependencia);
        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            String[] fila = new String[3];
            fila[0] = expediente.getIdExpediente();
            fila[1] = String.valueOf(expediente.getPrioridad());
            fila[2] = expediente.getAsunto();
            modeloTabla.addRow(fila);
        }
    }

    private void mostrarTablaFecha(String dependencia) {
        Lista<Expediente> listaExpedientes = this.s1.ExpedientesPorFecha(dependencia);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            String[] fila = new String[3];
            fila[0] = expediente.getIdExpediente();
            fila[1] = expediente.getFechaHoraInicio().format(formatter);
            fila[2] = expediente.getAsunto();
            modeloTabla2.addRow(fila);
        }
    }

    private void limpiarTablas() {
        modeloTabla.setRowCount(0);
        modeloTabla2.setRowCount(0);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        background = new javax.swing.JPanel();
        Bienvenido = new javax.swing.JLabel();
        intro = new javax.swing.JLabel();
        tramiteRealizar = new javax.swing.JLabel();
        ListPrioridad = new javax.swing.JScrollPane();
        tablafecha = new javax.swing.JTable();
        dependenciatxt = new javax.swing.JComboBox<>();
        ListPrioridad1 = new javax.swing.JScrollPane();
        tablaprioridad = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(750, 390));

        background.setBackground(new java.awt.Color(255, 255, 255));
        background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Bienvenido.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        Bienvenido.setText("Bienvenido");
        background.add(Bienvenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 710, -1));

        intro.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        intro.setText("Sistema de gestión para ULima. Controle y administre de forma óptima y fácil el flujo de trámites documentarios.\n");
        background.add(intro, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 710, 29));

        tramiteRealizar.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        tramiteRealizar.setText("Seleccione la dependencia");
        tramiteRealizar.setToolTipText("");
        background.add(tramiteRealizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, -1, -1));

        tablafecha.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "FechaEmision", "Asunto"
            }
        ));
        ListPrioridad.setViewportView(tablafecha);

        background.add(ListPrioridad, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 190, 310, 170));

        dependenciatxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dependenciatxtActionPerformed(evt);
            }
        });
        background.add(dependenciatxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 270, -1));

        tablaprioridad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Prioridad", "Asunto"
            }
        ));
        ListPrioridad1.setViewportView(tablaprioridad);

        background.add(ListPrioridad1, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 190, 310, 170));

        jLabel1.setText("Tramites pendientes por Antiguedad");
        background.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 170, -1, -1));

        jLabel2.setText("Tramites pendientes por prioridad");
        background.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void dependenciatxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dependenciatxtActionPerformed
        String dependencia = dependenciatxt.getSelectedItem().toString();
        limpiarTablas();
        mostrarTablaPrioridad(dependencia);
        mostrarTablaFecha(dependencia);
    }//GEN-LAST:event_dependenciatxtActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bienvenido;
    private javax.swing.JScrollPane ListPrioridad;
    private javax.swing.JScrollPane ListPrioridad1;
    private javax.swing.JPanel background;
    private javax.swing.JComboBox<String> dependenciatxt;
    private javax.swing.JLabel intro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTable tablafecha;
    private javax.swing.JTable tablaprioridad;
    private javax.swing.JLabel tramiteRealizar;
    // End of variables declaration//GEN-END:variables
}
