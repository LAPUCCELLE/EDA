package Dashboardventanas;
import javax.swing.JDialog;
import SistemaGestionTramite.*;


public class Crear extends javax.swing.JPanel {
  
    private GestionSistema s1;
  
    public Crear() {
        initComponents();
    }
    
    public Crear(GestionSistema s1) {
        initComponents();
        this.s1=s1;
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        background = new javax.swing.JPanel();
        usuario = new javax.swing.JLabel();
        interesado = new javax.swing.JLabel();
        expediente = new javax.swing.JLabel();
        expedienteBtn = new javax.swing.JButton();
        interesadoBtn = new javax.swing.JButton();
        usuarioBtn = new javax.swing.JButton();
        Crear = new javax.swing.JLabel();
        ListaInteresadoBtn = new javax.swing.JButton();
        ListaUsuarioBtn = new javax.swing.JButton();
        interesadoBtn3 = new javax.swing.JButton();

        background.setBackground(new java.awt.Color(255, 255, 255));

        usuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/usuario.jpg"))); // NOI18N

        interesado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/interesado.jpg"))); // NOI18N

        expediente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/expediente1.png"))); // NOI18N

        expedienteBtn.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        expedienteBtn.setForeground(new java.awt.Color(255, 153, 0));
        expedienteBtn.setText("Expediente");
        expedienteBtn.setBorder(null);
        expedienteBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        expedienteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expedienteBtnActionPerformed(evt);
            }
        });

        interesadoBtn.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        interesadoBtn.setForeground(new java.awt.Color(255, 153, 0));
        interesadoBtn.setText("Interesado");
        interesadoBtn.setBorder(null);
        interesadoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        interesadoBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                interesadoBtnActionPerformed(evt);
            }
        });

        usuarioBtn.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        usuarioBtn.setForeground(new java.awt.Color(255, 153, 0));
        usuarioBtn.setText("Usuario");
        usuarioBtn.setBorder(null);
        usuarioBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        usuarioBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuarioBtnActionPerformed(evt);
            }
        });

        Crear.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        Crear.setText("Crear");

        ListaInteresadoBtn.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        ListaInteresadoBtn.setForeground(new java.awt.Color(255, 153, 0));
        ListaInteresadoBtn.setText("Lista");
        ListaInteresadoBtn.setBorder(null);
        ListaInteresadoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ListaInteresadoBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListaInteresadoBtnActionPerformed(evt);
            }
        });

        ListaUsuarioBtn.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        ListaUsuarioBtn.setForeground(new java.awt.Color(255, 153, 0));
        ListaUsuarioBtn.setText("Lista");
        ListaUsuarioBtn.setBorder(null);
        ListaUsuarioBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ListaUsuarioBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListaUsuarioBtnActionPerformed(evt);
            }
        });

        interesadoBtn3.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        interesadoBtn3.setForeground(new java.awt.Color(255, 153, 0));
        interesadoBtn3.setText("Lista");
        interesadoBtn3.setBorder(null);
        interesadoBtn3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        interesadoBtn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                interesadoBtn3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout backgroundLayout = new javax.swing.GroupLayout(background);
        background.setLayout(backgroundLayout);
        backgroundLayout.setHorizontalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(backgroundLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(Crear, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(backgroundLayout.createSequentialGroup()
                        .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(backgroundLayout.createSequentialGroup()
                                .addGap(93, 93, 93)
                                .addComponent(ListaInteresadoBtn))
                            .addGroup(backgroundLayout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addComponent(interesadoBtn)))
                        .addGap(165, 165, 165)
                        .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(backgroundLayout.createSequentialGroup()
                                .addComponent(usuarioBtn)
                                .addGap(157, 157, 157)
                                .addComponent(expedienteBtn))
                            .addGroup(backgroundLayout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(ListaUsuarioBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(interesadoBtn3)
                                .addGap(31, 31, 31)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(interesado, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(expediente, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        backgroundLayout.setVerticalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(Crear, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(backgroundLayout.createSequentialGroup()
                        .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(interesado, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(backgroundLayout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(expedienteBtn)
                                .addComponent(interesadoBtn))
                            .addComponent(usuarioBtn)))
                    .addComponent(expediente))
                .addGap(18, 18, 18)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ListaInteresadoBtn)
                    .addComponent(ListaUsuarioBtn)
                    .addComponent(interesadoBtn3))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void expedienteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expedienteBtnActionPerformed
       javax.swing.SwingUtilities.invokeLater(new Runnable(){
           public void run(){
               try{
                   JDialog dialog = new JDialog();
                   dialog.setModal(true);
                   dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                   
                   Expedientes panelExpedientes = new Expedientes(s1);
                   dialog.add(panelExpedientes);
                   dialog.pack();
                   dialog.setLocationRelativeTo(null);
                   dialog.setVisible(true);
               } catch (Exception ex){
                   ex.printStackTrace();
               }
           }
       });
             
    }//GEN-LAST:event_expedienteBtnActionPerformed

    private void usuarioBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuarioBtnActionPerformed
        // Creamos el JDialog y lo mostramos con el panel usuario
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
            public void run(){
             JDialog dialog = new JDialog();
             dialog.setModal(true);
             dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                
            Usuario panelUsuario = new Usuario(s1);
            dialog.add(panelUsuario);
            dialog.pack();
            dialog.setLocationRelativeTo(null);
            dialog.setVisible(true);
            }
        });
    }//GEN-LAST:event_usuarioBtnActionPerformed

    private void interesadoBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_interesadoBtnActionPerformed
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
           public void run(){
               try{
                   JDialog dialog = new JDialog();
                   dialog.setModal(true);
                   dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                   
                   Interesados panelInteresados = new Interesados(s1);
                   dialog.add(panelInteresados);
                   dialog.pack();
                   dialog.setLocationRelativeTo(null);
                   dialog.setVisible(true);
               } catch (Exception ex){
                   ex.printStackTrace();
               }
           }
       });
    }//GEN-LAST:event_interesadoBtnActionPerformed

    private void ListaInteresadoBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListaInteresadoBtnActionPerformed
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
            public void run(){
             JDialog dialog = new JDialog();
             dialog.setModal(true);
             dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                
            ListaInteresados panelListaInteresados = new ListaInteresados(s1);
            dialog.add(panelListaInteresados);
            dialog.pack();
            dialog.setLocationRelativeTo(null);
            dialog.setVisible(true);
            }
        });
    }//GEN-LAST:event_ListaInteresadoBtnActionPerformed

    private void ListaUsuarioBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListaUsuarioBtnActionPerformed
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
            public void run(){
             JDialog dialog = new JDialog();
             dialog.setModal(true);
             dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                
            ListaUsuarios panelListaUsuario = new ListaUsuarios(s1);
            dialog.add(panelListaUsuario);
            dialog.pack();
            dialog.setLocationRelativeTo(null);
            dialog.setVisible(true);
            }
        });
    }//GEN-LAST:event_ListaUsuarioBtnActionPerformed

    private void interesadoBtn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_interesadoBtn3ActionPerformed
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
           public void run(){
               try{
                   JDialog dialog = new JDialog();
                   dialog.setModal(true);
                   dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                   
                   Registro panelRegistro = new Registro(s1);
                   dialog.add(panelRegistro);
                   dialog.pack();
                   dialog.setLocationRelativeTo(null);
                   dialog.setVisible(true);
               } catch (Exception ex){
                   ex.printStackTrace();
               }
           }
       });
    }//GEN-LAST:event_interesadoBtn3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Crear;
    private javax.swing.JButton ListaInteresadoBtn;
    private javax.swing.JButton ListaUsuarioBtn;
    private javax.swing.JPanel background;
    private javax.swing.JLabel expediente;
    private javax.swing.JButton expedienteBtn;
    private javax.swing.JLabel interesado;
    private javax.swing.JButton interesadoBtn;
    private javax.swing.JButton interesadoBtn3;
    private javax.swing.JLabel usuario;
    private javax.swing.JButton usuarioBtn;
    // End of variables declaration//GEN-END:variables
}
