
package Vista;
import java.awt.BorderLayout;
import Dashboardventanas.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.JPanel;
import SistemaGestionTramite.GestionSistema;
/**
 *
 * @author Rodrigo
 */
public class Dashboard extends javax.swing.JFrame {

    private GestionSistema s1;
    
    public Dashboard() {
        initComponents();
        SetDate();
        InitContent();
    }
    
    public Dashboard(GestionSistema s1) {
        this.s1 = s1;
        initComponents();
        SetDate();
        InitContent();
    }
    
    private void SetDate(){
        LocalDate now = LocalDate.now();
        Locale spanishLocale = new Locale("es", "ES");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("'Hoy es' EEEE dd 'de' MMMM 'de' yyyy").withLocale(spanishLocale);
        DayText.setText(now.format(formatter));
       
    }
    private void InitContent(){
        ShowJPanel(new Principal(s1));
    }
    
    private void ShowJPanel(JPanel p){
        p.setSize(750,390);
        p.setLocation(0,0);
        
        Contenido.removeAll();
        Contenido.add(p, BorderLayout.CENTER);
        Contenido.revalidate();
        Contenido.repaint();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton5 = new javax.swing.JButton();
        background = new javax.swing.JPanel();
        menu = new javax.swing.JPanel();
        Logo = new javax.swing.JLabel();
        CrearBtn = new javax.swing.JButton();
        PrincipalBtn = new javax.swing.JButton();
        GestionarBtn = new javax.swing.JButton();
        DependenciaBtn = new javax.swing.JButton();
        ConsultarBtn = new javax.swing.JButton();
        header = new javax.swing.JPanel();
        Administracion = new javax.swing.JLabel();
        DayText = new javax.swing.JLabel();
        Contenido = new javax.swing.JPanel();
        Bienvenido = new javax.swing.JLabel();
        CerrarSesion = new javax.swing.JButton();

        jButton5.setBackground(new java.awt.Color(0, 0, 0));
        jButton5.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/account-multiple.png"))); // NOI18N
        jButton5.setText("Crear dependencia");
        jButton5.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 12, 1, 1, new java.awt.Color(0, 0, 0)));
        jButton5.setBorderPainted(false);
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton5.setIconTextGap(13);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1020, 606));

        background.setBackground(new java.awt.Color(255, 255, 255));
        background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menu.setBackground(new java.awt.Color(0, 0, 0));
        menu.setPreferredSize(new java.awt.Dimension(270, 0));

        Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Ulmia.jpg"))); // NOI18N

        CrearBtn.setBackground(new java.awt.Color(0, 0, 0));
        CrearBtn.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        CrearBtn.setForeground(new java.awt.Color(255, 255, 255));
        CrearBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/account-multiple.png"))); // NOI18N
        CrearBtn.setText("Crear");
        CrearBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 12, 1, 1, new java.awt.Color(0, 0, 0)));
        CrearBtn.setBorderPainted(false);
        CrearBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CrearBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        CrearBtn.setIconTextGap(13);
        CrearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrearBtnActionPerformed(evt);
            }
        });

        PrincipalBtn.setBackground(new java.awt.Color(0, 0, 0));
        PrincipalBtn.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        PrincipalBtn.setForeground(new java.awt.Color(255, 255, 255));
        PrincipalBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/home-outline.png"))); // NOI18N
        PrincipalBtn.setText("Principal");
        PrincipalBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 12, 1, 1, new java.awt.Color(0, 0, 0)));
        PrincipalBtn.setBorderPainted(false);
        PrincipalBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PrincipalBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        PrincipalBtn.setIconTextGap(13);
        PrincipalBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrincipalBtnActionPerformed(evt);
            }
        });

        GestionarBtn.setBackground(new java.awt.Color(0, 0, 0));
        GestionarBtn.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        GestionarBtn.setForeground(new java.awt.Color(255, 255, 255));
        GestionarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/account-multiple.png"))); // NOI18N
        GestionarBtn.setText("Gestionar ");
        GestionarBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 12, 1, 1, new java.awt.Color(0, 0, 0)));
        GestionarBtn.setBorderPainted(false);
        GestionarBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        GestionarBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        GestionarBtn.setIconTextGap(13);
        GestionarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GestionarBtnActionPerformed(evt);
            }
        });

        DependenciaBtn.setBackground(new java.awt.Color(0, 0, 0));
        DependenciaBtn.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        DependenciaBtn.setForeground(new java.awt.Color(255, 255, 255));
        DependenciaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/calendar-plus.png"))); // NOI18N
        DependenciaBtn.setText("Dependencia");
        DependenciaBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 12, 1, 1, new java.awt.Color(0, 0, 0)));
        DependenciaBtn.setBorderPainted(false);
        DependenciaBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DependenciaBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        DependenciaBtn.setIconTextGap(13);
        DependenciaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DependenciaBtnActionPerformed(evt);
            }
        });

        ConsultarBtn.setBackground(new java.awt.Color(0, 0, 0));
        ConsultarBtn.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        ConsultarBtn.setForeground(new java.awt.Color(255, 255, 255));
        ConsultarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/book-open-page-variant.png"))); // NOI18N
        ConsultarBtn.setText("Consultar");
        ConsultarBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 12, 1, 1, new java.awt.Color(0, 0, 0)));
        ConsultarBtn.setBorderPainted(false);
        ConsultarBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ConsultarBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ConsultarBtn.setIconTextGap(13);
        ConsultarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultarBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout menuLayout = new javax.swing.GroupLayout(menu);
        menu.setLayout(menuLayout);
        menuLayout.setHorizontalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addGroup(menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(menuLayout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(PrincipalBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CrearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(GestionarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DependenciaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ConsultarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );
        menuLayout.setVerticalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(96, 96, 96)
                .addComponent(PrincipalBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(CrearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(DependenciaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(GestionarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ConsultarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        background.add(menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 606));

        header.setBackground(new java.awt.Color(255, 153, 51));
        header.setPreferredSize(new java.awt.Dimension(750, 150));

        Administracion.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        Administracion.setForeground(new java.awt.Color(255, 255, 255));
        Administracion.setText("Administración");

        DayText.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        DayText.setForeground(new java.awt.Color(255, 255, 255));
        DayText.setText("{dayname} {day} de {month} de {year}");

        javax.swing.GroupLayout headerLayout = new javax.swing.GroupLayout(header);
        header.setLayout(headerLayout);
        headerLayout.setHorizontalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DayText)
                    .addComponent(Administracion, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        headerLayout.setVerticalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(Administracion, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(DayText)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        background.add(header, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 60, 750, 150));

        Contenido.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout ContenidoLayout = new javax.swing.GroupLayout(Contenido);
        Contenido.setLayout(ContenidoLayout);
        ContenidoLayout.setHorizontalGroup(
            ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        ContenidoLayout.setVerticalGroup(
            ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );

        background.add(Contenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 216, 750, 390));

        Bienvenido.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Bienvenido.setText("¡Bienvenido de nuevo!");
        background.add(Bienvenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, 666, -1));

        CerrarSesion.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        CerrarSesion.setForeground(new java.awt.Color(255, 153, 0));
        CerrarSesion.setText("Cerrar Sesión");
        CerrarSesion.setBorder(null);
        CerrarSesion.setBorderPainted(false);
        CerrarSesion.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CerrarSesionActionPerformed(evt);
            }
        });
        background.add(CerrarSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 20, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CrearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrearBtnActionPerformed
       ShowJPanel(new Crear(s1));
    }//GEN-LAST:event_CrearBtnActionPerformed

    private void PrincipalBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrincipalBtnActionPerformed
       ShowJPanel(new Principal(s1)); 
    }//GEN-LAST:event_PrincipalBtnActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void GestionarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GestionarBtnActionPerformed
        ShowJPanel(new Gestionar(s1));
    }//GEN-LAST:event_GestionarBtnActionPerformed

    private void CerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CerrarSesionActionPerformed
        Login mainFrame = new Login(s1);
        mainFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_CerrarSesionActionPerformed

    private void DependenciaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DependenciaBtnActionPerformed
        ShowJPanel(new Dependencias(s1));
    }//GEN-LAST:event_DependenciaBtnActionPerformed

    private void ConsultarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultarBtnActionPerformed
       ShowJPanel(new Consultar(s1));
    }//GEN-LAST:event_ConsultarBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Administracion;
    private javax.swing.JLabel Bienvenido;
    private javax.swing.JButton CerrarSesion;
    private javax.swing.JButton ConsultarBtn;
    private javax.swing.JPanel Contenido;
    private javax.swing.JButton CrearBtn;
    private javax.swing.JLabel DayText;
    private javax.swing.JButton DependenciaBtn;
    private javax.swing.JButton GestionarBtn;
    private javax.swing.JLabel Logo;
    private javax.swing.JButton PrincipalBtn;
    private javax.swing.JPanel background;
    private javax.swing.JPanel header;
    private javax.swing.JButton jButton5;
    private javax.swing.JPanel menu;
    // End of variables declaration//GEN-END:variables
}
