/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaGestionTramite;
import TDA.*;

/**
 *
 * @author User
 */
public class Dependencia {
    private String nombre;
    private Lista<Expediente> listaExpedientes;

    public Dependencia(String nombre) {
        this.nombre = nombre;
        this.listaExpedientes = new Lista<>();
    }

    
    public void agregarExpediente(Expediente expediente){
        listaExpedientes.agregar(expediente);
    }
    
    public Expediente buscarExpediente(String idExpediente) {
        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            if (expediente.getIdExpediente().equals(idExpediente)) {
                return expediente;
            }
        }
        return null;
    }
    
    public Expediente moverExpediente() {
        if (!listaExpedientes.esVacia()) {
            return listaExpedientes.iesimo(1); 
        }
        return null;
    }
    
    public void eliminarExpediente(Expediente expediente) {
        listaExpedientes.eliminar(expediente);
    }
    
    public Lista<Expediente> obtenerExpedientesPorPrioridad() {
        Lista<Expediente> listaExpedientesOrdenados = new Lista<>();

        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            if (!expediente.estaAtendido()) {
                listaExpedientesOrdenados.agregar(expediente);
            }
        }

        // Ordenar lista de expedientes por prioridad usando el método de burbuja
        for (int i = 1; i < listaExpedientesOrdenados.longitud(); i++) {
            for (int j = 1; j < listaExpedientesOrdenados.longitud() - i + 1; j++) {
                if (listaExpedientesOrdenados.iesimo(j).getPrioridad() > listaExpedientesOrdenados.iesimo(j + 1).getPrioridad()) {
                    // Intercambiar expedientes
                    Expediente temp = listaExpedientesOrdenados.iesimo(j);
                    listaExpedientesOrdenados.eliminar(j);
                    listaExpedientesOrdenados.insertar(temp, j + 1);
                }
            }
        }

        return listaExpedientesOrdenados;
    }

   
    public Lista<Expediente> obtenerExpedientesPorAntiguedad() {
        Lista<Expediente> listaExpedientesOrdenados = new Lista<>();

        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            if (!expediente.estaAtendido()) {
                listaExpedientesOrdenados.agregar(expediente);
            }
        }

        // Ordenar lista de expedientes por antigüedad (más antiguo a más reciente)
        for (int i = 1; i < listaExpedientesOrdenados.longitud(); i++) {
            for (int j = 1; j < listaExpedientesOrdenados.longitud() - i + 1; j++) {
                if (listaExpedientesOrdenados.iesimo(j).getFechaHoraInicio().isAfter(listaExpedientesOrdenados.iesimo(j + 1).getFechaHoraInicio())) {
                    // Intercambiar expedientes
                    Expediente temp = listaExpedientesOrdenados.iesimo(j);
                    listaExpedientesOrdenados.eliminar(j);
                    listaExpedientesOrdenados.insertar(temp, j + 1);
                }
            }
        }

        return listaExpedientesOrdenados;
    }
    
    public Lista<Expediente> obtenerTodosLosExpedientes() {
        Lista<Expediente> listaExpedientesCopia = new Lista<>();

        for (int i = 1; i <= listaExpedientes.longitud(); i++) {
            Expediente expediente = listaExpedientes.iesimo(i);
            listaExpedientesCopia.agregar(expediente);
        }

        return listaExpedientesCopia;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Lista<Expediente> getListaExpedientes() {
        return listaExpedientes;
    }

    public void setListaExpedientes(Lista<Expediente> listaExpedientes) {
        this.listaExpedientes = listaExpedientes;
    }


    @Override
    public String toString() {
        return this.nombre ;
    }
}

