
package SistemaGestionTramite;

public class Administrador {
    private String nombreDeUsuario;
    private String contraseña;
    

    public Administrador(String nombreDeUsuario, String contraseña) {
        this.nombreDeUsuario = nombreDeUsuario;
        this.contraseña = contraseña;
    }

    public boolean validarAcceso(String username, String password) {
        return this.nombreDeUsuario.equals(username) && this.contraseña.equals(password);
    }
    
    public void cambiarContraseña(String nuevaContraseña) {
        this.contraseña = nuevaContraseña;
    }
    
    public String getNombreDeUsuario() {
        return nombreDeUsuario;
    }

    public void setNombreDeUsuario(String nombreDeUsuario) {
        this.nombreDeUsuario = nombreDeUsuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    @Override
    public String toString() {
        return "Administrador: " + nombreDeUsuario;
    }
    
}
