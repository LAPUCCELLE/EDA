/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaGestionTramite;
import TDA.*;

/**
 *
 * @author User
 */
public class Dependencia {
    private String nombre;
    private Cola<Expediente> colaExpedientes;


    public Dependencia(String nombre) {
        this.nombre = nombre;
        this.colaExpedientes = new Cola<>();
    }
    
    public void agregarExpediente(Expediente expediente){
        colaExpedientes.encolar(expediente);
    }
    
    public Expediente buscarExpediente(String idExpediente) {
        Cola<Expediente> colatmp = new Cola<>();
        Expediente expedienteEncontrado = null;

        while (!colaExpedientes.esVacia()) {
            Expediente expediente = colaExpedientes.desencolar();
            if (expediente.getIdExpediente().equals(idExpediente)) {
                expedienteEncontrado = expediente;
            }
            colatmp.encolar(expediente);
        }

        // Restaurar el estado original de la cola
        while (!colatmp.esVacia()) {
            colaExpedientes.encolar(colatmp.desencolar());
        }

        return expedienteEncontrado;
    }
    
    public Expediente moverExpediente() {
        if (!colaExpedientes.esVacia()) {
            return colaExpedientes.desencolar();
        }
        return null;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Cola<Expediente> getColaExpedientes() {
        return colaExpedientes;
    }

    public void setColaExpedientes(Cola<Expediente> colaExpedientes) {
        this.colaExpedientes = colaExpedientes;
    }
    
    @Override
    public String toString() {
        return this.nombre ;
    }
}

